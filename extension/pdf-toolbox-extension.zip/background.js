'use strict';
const TOOL = 'index.html';
const PDF_PATTERNS = ['*://*/*.pdf', '*://*/*.pdf?*', '*://*/*.pdf#*', '*://*/*.PDF', '*://*/*.PDF?*', '*://*/*.PDF#*', 'file:///*.pdf', 'file:///*.PDF'];
const isWebUrl = u => /^(https?|file):/i.test(u || '');
const isPdfUrl = u => { try { return isWebUrl(u) && /\.pdf$/i.test(new URL(u).pathname); } catch (e) { return false; } };
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'openLink', title: '用 PDF 工具箱開啟', contexts: ['link'], targetUrlPatterns: PDF_PATTERNS });
    chrome.contextMenus.create({ id: 'openPage', title: '把這份 PDF 送進 PDF 工具箱', contexts: ['page'], documentUrlPatterns: PDF_PATTERNS });
  });
});
async function toolTab() {
  try {
    const base = chrome.runtime.getURL(TOOL);
    const list = await chrome.runtime.getContexts({ contextTypes: ['TAB'] });
    return list.filter(c => c.tabId >= 0 && (c.documentUrl || '').startsWith(base)).pop() || null;
  } catch (e) { return null; }
}
async function openTool(src, tab) {
  let page = TOOL, id = null;
  if (src) {
    id = crypto.randomUUID();
    await chrome.storage.session.set({ ['job:' + id]: { url: src, at: Date.now() } });
  }
  const t = await toolTab();
  if (t) {
    await chrome.tabs.update(t.tabId, { active: true });
    if (t.windowId >= 0) await chrome.windows.update(t.windowId, { focused: true });
    if (id) await chrome.runtime.sendMessage({ type: 'pdfbox-job', id, tabId: t.tabId }).catch(() => {});
    return t;
  }
  if (id) page += '#job=' + id;
  const opt = { url: chrome.runtime.getURL(page) };
  if (tab && tab.id >= 0) { opt.index = tab.index + 1; opt.openerTabId = tab.id; }
  return chrome.tabs.create(opt);
}
async function tabIsPdf(tab) {
  if (isPdfUrl(tab.url)) return true;
  if (!isWebUrl(tab.url)) return false;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.contentType });
    return !!r && r.result === 'application/pdf';
  } catch (e) { return false; }
}
async function onAction(tab) {
  return openTool(await tabIsPdf(tab) ? tab.url : null, tab);
}
function onMenu(info, tab) {
  if (info.menuItemId === 'openLink') return openTool(info.linkUrl, tab);
  if (info.menuItemId === 'openPage') return openTool(info.frameUrl || info.pageUrl, tab);
}
chrome.action.onClicked.addListener(onAction);
chrome.contextMenus.onClicked.addListener(onMenu);
