'use strict';
const EXT_WAIT = 30000;
const EXT_BODY_WAIT = 120000;
const EXT_COOKIE_MODE = 'include';
function extNotice(id, msg, buttons, lines) {
  let bar = $(id);
  if (!bar) {
    bar = document.createElement('div');
    bar.id = id;
    bar.style.cssText = 'display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:8px 16px;font-size:14px;background:var(--accent-soft);color:var(--text);border-bottom:1px solid var(--line)';
    $('libErr').after(bar);
  }
  bar.replaceChildren();
  const span = document.createElement('span');
  span.textContent = msg;
  bar.append(span);
  for (const [text, fn] of buttons || []) {
    const b = document.createElement('button');
    b.textContent = text;
    b.onclick = fn;
    bar.append(b);
  }
  const x = document.createElement('button');
  x.textContent = '✕'; x.title = '關閉';
  x.onclick = () => bar.remove();
  bar.append(x);
  if (lines && lines.length) {
    const ul = document.createElement('ul');
    ul.style.cssText = 'flex-basis:100%;margin:0;padding-left:22px';
    for (const t of lines) { const li = document.createElement('li'); li.textContent = t; ul.append(li); }
    bar.append(ul);
  }
}
function extBar(msg, btnText, onBtn) { extNotice('extBar', msg, btnText ? [[btnText, onBtn]] : []); }
function extFileName(url, res) {
  const cd = (res && res.headers.get('content-disposition')) || '';
  let name = '';
  const star = /filename\*\s*=\s*[^']*''([^;]+)/i.exec(cd);
  const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(cd);
  try { name = star ? decodeURIComponent(star[1]) : plain ? plain[1] : decodeURIComponent(new URL(url).pathname.split('/').pop()); }
  catch (e) { name = ''; }
  name = name.replace(/[\\/:*?"<>|]/g, '_').trim() || '網頁上的PDF';
  return /\.pdf$/i.test(name) ? name : name + '.pdf';
}
async function extFetch(url) {
  const ctl = new AbortController();
  let t = setTimeout(() => ctl.abort(), EXT_WAIT);
  try {
    const res = await fetch(url, { credentials: EXT_COOKIE_MODE, signal: ctl.signal });
    if (!res.ok) throw Object.assign(new Error('http'), { status: res.status });
    clearTimeout(t); t = setTimeout(() => ctl.abort(), EXT_BODY_WAIT);
    return { res, bytes: new Uint8Array(await res.arrayBuffer()) };
  } finally { clearTimeout(t); }
}
const extHasPdfHead = b => new TextDecoder('latin1').decode(b.subarray(0, 1024)).includes('%PDF-');
async function extOpenUrl(url) {
  const u = new URL(url);
  let got;
  busy('從網頁讀取 PDF 中…');
  try { got = await extFetch(url); }
  catch (e) {
    busy(null);
    if (e.name === 'AbortError') return extBar('等太久沒有回應，請確認網路後再試一次，或先把 PDF 下載下來再拖進來。');
    if (e.status) return extBar(`這個網站拒絕讓工具箱讀取（代碼 ${e.status}），可能要先登入。請先把 PDF 下載下來，再拖進來。`);
    if (u.protocol === 'file:') {
      return extBar('讀不到電腦裡的這個檔案。請直接把檔案拖進來；或到「管理擴充功能」→ PDF 工具箱 →「詳細資料」，打開「允許存取檔案網址」。');
    }
    const origin = u.origin + '/*';
    if (await chrome.permissions.contains({ origins: [origin] })) {
      return extBar('讀取失敗（可能要先登入那個網站，或網路不通）。請先把 PDF 下載下來，再拖進來。');
    }
    return extBar(`要讀取「${u.host}」上的 PDF，需要你同意一次（只會讀你送進來的 PDF）。`, `允許讀取 ${u.host}`, async () => {
      const ok = await chrome.permissions.request({ origins: [origin] }).catch(() => false);
      if (ok) { $('extBar') && $('extBar').remove(); extOpenUrl(url); }
      else extBar('沒有同意，所以讀不到。也可以先把 PDF 下載下來，再拖進來。');
    });
  }
  busy(null);
  if (!extHasPdfHead(got.bytes)) return extBar('這個網址拿到的不是 PDF（可能要先登入那個網站）。請先把 PDF 下載下來，再拖進來。');
  const file = new File([got.bytes], extFileName(url, got.res), { type: 'application/pdf', lastModified: Date.now() });
  if (!VIEWER_TABS.includes(curTab) && curTab !== 'organize') setTab('organize');
  await openFiles([file]);
}
async function extTakeJob(id) {
  const key = 'job:' + id;
  const job = (await chrome.storage.session.get(key))[key];
  await chrome.storage.session.remove(key);
  if (job && job.url && LIBS_OK) await extOpenUrl(job.url);
}
let extQueue = Promise.resolve();
function extRunJob(id) {
  extQueue = extQueue.then(() => extTakeJob(id))
    .catch(e => { busy(null); console.error(e); toast('讀取 PDF 失敗，請先下載下來再拖進來', 4000); });
  return extQueue;
}
const extTabId = chrome.tabs.getCurrent().then(t => (t ? t.id : -1)).catch(() => -1);
chrome.runtime.onMessage.addListener(msg => {
  if (!msg || msg.type !== 'pdfbox-job' || !/^[\w-]+$/.test(String(msg.id))) return;
  extTabId.then(id => { if (id === msg.tabId) extRunJob(msg.id); });
});
const extFirst = /^#job=([\w-]+)$/.exec(location.hash);
if (extFirst) { history.replaceState(null, '', location.pathname); extRunJob(extFirst[1]); }
const EXT_SITE = 'https://r-toooooooooool.github.io/pdf-toolbox/';
const EXT_VER_URL = EXT_SITE + 'extension/version.json';
const EXT_ZIP_URL = EXT_SITE + 'extension/pdf-toolbox-extension.zip';
const EXT_VER = chrome.runtime.getManifest().version;
function extNewer(a, b) {
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  }
  return false;
}
function extWhatsNew(history) {
  if (!Array.isArray(history)) return [];
  const [y, m, d] = EXT_VER.split('.').map(Number);
  const mine = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const ok = history.filter(h => h && typeof h.date === 'string' && Array.isArray(h.notes));
  const pick = ok.filter(h => h.date > mine);
  const lines = (pick.length ? pick : ok.slice(0, 1)).flatMap(h => h.notes).filter(t => typeof t === 'string' && t.trim());
  return lines.slice(0, 8).map(t => t.trim().slice(0, 80));
}
function extUpdateBar(ver, lines) {
  const skip = async () => { await chrome.storage.local.set({ skipVersion: ver }); $('extUpd') && $('extUpd').remove(); toast('這一版先不更新；之後有更新的版本會再提醒你'); };
  const steps = () => extNotice('extUpd',
    '下載好之後：在下載的壓縮檔按右鍵 →「全部解壓縮」→ 按「瀏覽」選你原本放擴充功能的資料夾 → 解壓縮，問要不要取代時選「取代」。換好再按右邊的按鈕。',
    [['換好了，重新載入', () => chrome.runtime.reload()], ['這版先不要', skip]]);
  extNotice('extUpd', `PDF 工具箱擴充功能有新版（${ver}，你現在是 ${EXT_VER}）。` + (lines.length ? '新版多了這些：' : '要更新嗎？'),
    [['下載新版', () => { chrome.tabs.create({ url: EXT_ZIP_URL }); steps(); }], ['這版先不要', skip]], lines);
}
async function extCheckUpdate() {
  if ((await chrome.storage.local.get('noUpdateCheck')).noUpdateCheck) return;
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), EXT_WAIT);
  try {
    const res = await fetch(EXT_VER_URL, { cache: 'no-store', credentials: 'omit', signal: ctl.signal });
    if (!res.ok) return;
    const info = await res.json();
    const ver = String(info.version || '');
    if (!/^\d+(\.\d+){0,3}$/.test(ver) || !extNewer(ver, EXT_VER)) return;
    const { skipVersion } = await chrome.storage.local.get('skipVersion');
    if (skipVersion && !extNewer(ver, skipVersion)) return;
    extUpdateBar(ver, extWhatsNew(info.history));
  } catch (e) {   }
  finally { clearTimeout(t); }
}
(async () => {
  const { lastVersion } = await chrome.storage.local.get('lastVersion');
  if (lastVersion && lastVersion !== EXT_VER) toast(`已經更新到新版 ${EXT_VER}`, 4000);
  if (lastVersion !== EXT_VER) await chrome.storage.local.set({ lastVersion: EXT_VER });
})().catch(() => {});
if ($('extVer')) $('extVer').textContent = EXT_VER;
if ($('extUpdOn')) {
  chrome.storage.local.get('noUpdateCheck').then(r => { $('extUpdOn').checked = !r.noUpdateCheck; });
  $('extUpdOn').onchange = async e => {
    await chrome.storage.local.set({ noUpdateCheck: !e.target.checked });
    toast(e.target.checked ? '有新版時會提醒你' : '不會再提醒新版；要更新時可以到說明頁重新打開');
    if (e.target.checked) extCheckUpdate();
  };
}
extCheckUpdate();
